/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalunlpsubsidios;

/**
 *
 * @author Usuario
 */
public class SubsidioDeBienes extends Subsidio{
    private int cantidadBienes;
    private Bien[] bienes;
    private int dimL;

    public SubsidioDeBienes(int cantidadBienes, String nombreInvestigador, String nombrePlanDeTrabajo, int fechaSolicitud) {
        super(nombreInvestigador, nombrePlanDeTrabajo, fechaSolicitud);
        this.cantidadBienes = cantidadBienes;
        bienes = new Bien[cantidadBienes];  // la inicializacion la hace java
        dimL = 0;
    }
    
    public void agregarBien(Bien bien1){
        if(dimL <= (cantidadBienes - 1)){
            bienes[dimL] = bien1;
            dimL++;
        }
    }
    
    @Override
    public double devolverMontoTotal(){
        double aux = 0;
        int i;
        for(i=0 ; i<= (dimL - 1); i++){
            aux+= bienes[i].devolverMontoBien();
        }
        return aux;
    }
    
    @Override
    public String toString(){
        String aux = super.toString() + "--Monto total:  " + this.devolverMontoTotal() + "\n";
        int i;
        for(i=0; i<= (dimL -1) ; i++){
            aux+= "Bien" + (i+1) + ": " + bienes[i].getDescripcion() + "\n";
        }
        return aux;
    }    
}
