/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalunlpsubsidios;

/**
 *
 * @author Usuario
 */
public class Bien {
    private String descripcion;
    private int cantidad;
    private double costoXunidad;

    public Bien(String descripcion, int cantidad, double costoXunidad) {
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.costoXunidad = costoXunidad;
    }
    
    public double devolverMontoBien(){
        double aux = this.cantidad * this.costoXunidad;
        return aux;
    }

    public String getDescripcion() {
        return descripcion;
    }
    
    
    
}
