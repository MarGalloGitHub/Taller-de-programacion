/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalunlpsubsidios;

/**
 *
 * @author Usuario
 */
public abstract class Subsidio{
    private String nombreInvestigador;
    private String nombrePlanDeTrabajo;
    private int fechaSolicitud;

    public Subsidio(String nombreInvestigador, String nombrePlanDeTrabajo, int fechaSolicitud) {
        this.nombreInvestigador = nombreInvestigador;
        this.nombrePlanDeTrabajo = nombrePlanDeTrabajo;
        this.fechaSolicitud = fechaSolicitud;
    }
    
    public abstract double devolverMontoTotal();
     
    @Override
    public String toString(){
        String aux = "Nombre del investigador: " + this.nombreInvestigador + "--Plan de trabajo:  " + this.nombrePlanDeTrabajo + "--Fecha de solicitud:  " + this.fechaSolicitud;
        return aux;
    }
  
}
