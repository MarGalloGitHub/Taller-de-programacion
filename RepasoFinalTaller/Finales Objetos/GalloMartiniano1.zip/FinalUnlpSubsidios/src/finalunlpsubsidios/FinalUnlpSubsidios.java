/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalunlpsubsidios;

/**
 *
 * @author Usuario
 */
import PaqueteLectura.Lector;
public class FinalUnlpSubsidios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            
            System.out.println("cargue los datos para un subsidio de estadia: LUGAR DE DESTINO, COSTO DE PASAJES, CANTIDAD DIAS DE ESTADIA, MONTO POR DIA, NOMBRE DEL INVESTIGADOR, NOMBRE DEL PLAN DE TRABAJO Y FECHA DE SOLICITUD ");
            SubsidioDeEstadia estadia1 = new SubsidioDeEstadia(Lector.leerString(),Lector.leerDouble(),Lector.leerInt(),Lector.leerDouble(),Lector.leerString(),Lector.leerString(),Lector.leerInt());
            
            
            System.out.println("cargue los datos para un subsidio de bienes: CANTIDAD MAXIMA DE BIENES, NOMBRE DEL INVESTIGADOR, NOMBRE DEL PLAN DE TRABAJO Y FECHA DE SOLICITUD ");
            SubsidioDeBienes bienes1 = new SubsidioDeBienes(Lector.leerInt(),Lector.leerString(),Lector.leerString(),Lector.leerInt());
            
            System.out.println("cargue los datos de un bien: DESCRIPCION, CANTIDAD Y COSTO X UNIDAD ");
            Bien bien1 = new Bien(Lector.leerString(),Lector.leerInt(),Lector.leerDouble());
            
            System.out.println("cargue los datos de un bien: DESCRIPCION, CANTIDAD Y COSTO X UNIDAD ");
            Bien bien2 = new Bien(Lector.leerString(),Lector.leerInt(),Lector.leerDouble());
            
            System.out.println("cargue los datos de un bien: DESCRIPCION, CANTIDAD Y COSTO X UNIDAD ");
            Bien bien3 = new Bien(Lector.leerString(),Lector.leerInt(),Lector.leerDouble());
            
            bienes1.agregarBien(bien1);
            bienes1.agregarBien(bien2);
            bienes1.agregarBien(bien3);
            
            System.out.println("Informacio del subsidio de estadia:  " + estadia1.toString());
            System.out.println("Informacio del subsidio de bienes:  " + bienes1.toString());
    }
    
}
