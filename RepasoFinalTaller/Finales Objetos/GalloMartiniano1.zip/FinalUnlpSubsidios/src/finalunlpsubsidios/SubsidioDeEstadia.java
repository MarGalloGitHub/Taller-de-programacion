/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalunlpsubsidios;

/**
 *
 * @author Usuario
 */
public class SubsidioDeEstadia extends Subsidio{
    private String lugarDeDestino;
    private double costoPasajes;
    private int diasEstadia;
    private double montoHotelXdia;

    public SubsidioDeEstadia(String lugarDeDestino, double costoPasajes, int diasEstadia, double montoHotelXdia, String nombreInvestigador, String nombrePlanDeTrabajo, int fechaSolicitud) {
        super(nombreInvestigador, nombrePlanDeTrabajo, fechaSolicitud);
        this.lugarDeDestino = lugarDeDestino;
        this.costoPasajes = costoPasajes;
        this.diasEstadia = diasEstadia;
        this.montoHotelXdia = montoHotelXdia;
    }
    
    @Override
    public double devolverMontoTotal(){
        double aux = this.costoPasajes + (this.diasEstadia * this.montoHotelXdia);
        return aux;
    }
    
    @Override
    public String toString(){
        String aux = super.toString() + "--Lugar de destino:  " + this.lugarDeDestino + "--Dias de estadia:  " + this.diasEstadia + "-- Monto total:  " + this.devolverMontoTotal();
        return aux;
    }
    
}
