/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalapuestas;

/**
 *
 * @author Usuario
 */
import PaqueteLectura.Lector;
public class FinalApuestas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("cuantos partidos tendra el sistema:  ");
        int numPartidos = Lector.leerInt();
        System.out.println("cuantas apuestas tendra el sistema:  ");
        int numApuestas = Lector.leerInt();
        Sistema sistema1 = new Sistema(numPartidos,numApuestas);
        
        int i;
        for(i=0 ; i<=(numPartidos - 1) ; i++){
            System.out.println("cargue la informacion de un partido: NOMBRE LOCAL, NOMBRE VISITANTE, FACTOR VICTORIA LOCAL, FACTOR VICTORIA VISITANTE Y FACTOR EMPATE ");
            Partido partido1 = new Partido(Lector.leerString(),Lector.leerString(),Lector.leerDouble(),Lector.leerDouble(),Lector.leerDouble());
            sistema1.ingresarResultado(sistema1.agregarPartidoEID(partido1));
        }
        
        for(i=0 ; i<=(numApuestas - 1) ; i++){
            System.out.println("cargue la informacion de una apuesta: NOMBRE DE CLIENTE, DNI DEL CLIENTE, ID UNICO, APUESTA QUE HIZO(EMPATE VICTORIA LOCAL O VISITANTE) Y MONTO APOSTADO ");
            Apuesta apuesta1 = new Apuesta(Lector.leerString(),Lector.leerInt(),Lector.leerInt(),Lector.leerString(),Lector.leerDouble());
            sistema1.agregarApuesta(apuesta1);
        }
        
        sistema1.cerrarApuestas();
        sistema1.LimpiarSistema();
    }
    
}
