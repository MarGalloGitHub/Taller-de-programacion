/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalapuestas;

/**
 *
 * @author Usuario
 */
import PaqueteLectura.Lector;
public class Sistema {
    private Partido[] partidos;
    private int cantidadPartidos;
    private Apuesta[] apuestas;
    private int cantidadApuestas;
    private int dimLPartidos;
    private int dimLApuestas;

    public Sistema(int cantidadPartidos, int cantApuestas) {
        this.cantidadPartidos = cantidadPartidos;
        this.cantidadApuestas = cantApuestas;
        partidos = new Partido[cantidadPartidos];
        apuestas = new Apuesta[cantidadApuestas];
        dimLPartidos = 0;
        dimLApuestas = 0;
        
    }

    
    public void agregarApuesta(Apuesta apuesta1){
        if(dimLApuestas <= (cantidadApuestas - 1)){
            apuestas[dimLApuestas] = apuesta1;
            dimLApuestas++;
        }
    }
    
    public int agregarPartidoEID(Partido partido1){
        int aux = 0;
        if(dimLPartidos <= (cantidadPartidos - 1)){
            partidos[dimLPartidos] = partido1;
            aux = dimLPartidos + 1;
            dimLPartidos++;
        }
        return aux;
    }
    
    public void ingresarResultado(int ID){
        if((ID <= 20) && (ID >= 1)){
            System.out.println("cambie el resultado del partido con ID:  " + ID + ", CON VICTORIA LOCAL, VICTORIA VISITANTE O EMPATE");
            partidos[ID - 1].setResultado(Lector.leerString());
            
        }
    }
    
    public void cerrarApuestas(){
        int i;
        double aux = 0;
        for(i=0 ; i<= (dimLApuestas - 1) ; i++){
            if(apuestas[i].getApuestaQueHizo().equals(partidos[apuestas[i].getIDunico() - 1].getResultado())){
                if(apuestas[i].getApuestaQueHizo().equals("VICTORIA LOCAL")){
                    aux = apuestas[i].getMontoApostado() * partidos[apuestas[i].getIDunico()].getFactorPagoVictoriaLocal();
                }
                else
                    if(apuestas[i].getApuestaQueHizo().equals("VICTORIA visitante")){
                        aux = apuestas[i].getMontoApostado() * partidos[apuestas[i].getIDunico()].getFactorPagoVictoriaVisitante();
                }
                else
                        if(apuestas[i].getApuestaQueHizo().equals("EMPATE")){
                            aux = apuestas[i].getMontoApostado() * partidos[apuestas[i].getIDunico()].getFactorPagoEmpate();
                }
                
                System.out.println("La persona:  " + apuestas[i].getNombreCliente()+ ", con el DNI:  " + apuestas[i].getDniCliente() + " acerto la apuesta y su monto por acertar fue:  " + aux);
            }
        }
    }
    
    public void LimpiarSistema(){
        this.partidos = new Partido[this.cantidadPartidos];
        this.apuestas = new Apuesta[this.cantidadApuestas];
    }

    public Apuesta[] getApuestas() {
        return apuestas;
    }
    
    
}
