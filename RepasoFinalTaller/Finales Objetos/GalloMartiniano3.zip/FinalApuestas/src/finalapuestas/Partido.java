/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalapuestas;

/**
 *
 * @author Usuario
 */
public class Partido {
    private String nombreLocal;
    private String nombreVisitante;
    private String resultado;
    private double FactorPagoVictoriaLocal;
    private double FactorPagoVictoriaVisitante;
    private double FactorPagoEmpate;

    public Partido(String nombreLocal, String nombreVisitante, double FactorPagoVictoriaLocal, double FactorPagoVictoriaVisitante, double FactorPagoEmpate) {
        this.nombreLocal = nombreLocal;
        this.resultado = "  ";
        this.nombreVisitante = nombreVisitante;
        this.FactorPagoVictoriaLocal = FactorPagoVictoriaLocal;
        this.FactorPagoVictoriaVisitante = FactorPagoVictoriaVisitante;
        this.FactorPagoEmpate = FactorPagoEmpate;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public String getNombreLocal() {
        return nombreLocal;
    }

    public String getNombreVisitante() {
        return nombreVisitante;
    }

    public double getFactorPagoVictoriaLocal() {
        return FactorPagoVictoriaLocal;
    }

    public double getFactorPagoVictoriaVisitante() {
        return FactorPagoVictoriaVisitante;
    }

    public double getFactorPagoEmpate() {
        return FactorPagoEmpate;
    }
    
    
    
}
