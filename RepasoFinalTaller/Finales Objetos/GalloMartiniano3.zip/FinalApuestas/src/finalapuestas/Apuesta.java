/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalapuestas;

/**
 *
 * @author Usuario
 */
public class Apuesta {
    private String nombreCliente;
    private int dniCliente;
    private int IDunico;
    private String apuestaQueHizo;
    private double montoApostado;

    public Apuesta(String nombreCliente, int dniCliente, int IDunico, String apuestaQueHizo, double montoApostado) {
        this.nombreCliente = nombreCliente;
        this.dniCliente = dniCliente;
        this.IDunico = IDunico;
        this.apuestaQueHizo = apuestaQueHizo;
        this.montoApostado = montoApostado;
    }

    public String getApuestaQueHizo() {
        return apuestaQueHizo;
    }

    public int getIDunico() {
        return IDunico;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public int getDniCliente() {
        return dniCliente;
    }

    public double getMontoApostado() {
        return montoApostado;
    }
    
    
    
}
