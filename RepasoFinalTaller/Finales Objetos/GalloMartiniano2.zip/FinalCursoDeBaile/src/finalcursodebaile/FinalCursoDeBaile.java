/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalcursodebaile;

/**
 *
 * @author Usuario
 */
public class FinalCursoDeBaile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Concurso concurso1 = new Concurso(2);
        
        concurso1.agregarPareja();
        concurso1.agregarPareja();
        
      
        System.out.println(" Los nombre de la pareja con mas diferencia de edad son:  " + concurso1.obtenerParejaConMasDiferencia().toString());
    }
    
}
