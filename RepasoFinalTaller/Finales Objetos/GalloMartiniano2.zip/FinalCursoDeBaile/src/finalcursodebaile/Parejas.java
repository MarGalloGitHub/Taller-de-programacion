/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalcursodebaile;

/**
 *
 * @author Usuario
 */
public class Parejas {
    private String estiloDeBaile;
    private Participante miembro1;  // podria haber usado un vector??
    private Participante miembro2;

    public Parejas(String estiloDeBaile, Participante miembro1, Participante miembro2) {
        this.estiloDeBaile = estiloDeBaile;
        this.miembro1 = miembro1;
        this.miembro2 = miembro2;
    }
    
    public int obtenerDiferenciaEdad(){
        int aux = miembro1.getEdad() - miembro2.getEdad();
        if(aux < 0){
            aux = aux*(-1);
        }
        return aux;
    }
    
    @Override
    public String toString(){
        String aux = this.miembro1.getNombre() + ", y    " + this.miembro2.getNombre();
        return aux;
    }
}   
