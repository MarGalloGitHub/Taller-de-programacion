/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalcursodebaile;

/**
 *
 * @author Usuario
 */
import PaqueteLectura.Lector;
public class Concurso {
    private int cantidadParejas;
    private Parejas[] parejas;
    private int dimL;

    public Concurso(int cantidadParejas) {
        this.cantidadParejas = cantidadParejas;
        parejas = new Parejas[cantidadParejas];  // no inicializo porque lo hace java
        dimL = 0;
    }
    
    
    public void agregarPareja(){
        if(dimL <= (cantidadParejas - 1)){
            System.out.println("cargue los datos de una pareja");
            Parejas pareja1;
            
            System.out.println("cargue los datos de un participante = DNI, NOMBRE Y EDAD");
            Participante parti1 = new Participante(Lector.leerInt(),Lector.leerString(),Lector.leerInt());
            
            System.out.println("cargue los datos de otro participante = DNI, NOMBRE Y EDAD");
            Participante parti2 = new Participante(Lector.leerInt(),Lector.leerString(),Lector.leerInt());
            
            System.out.println("que estilo de baile tiene la pareja:  ");
            String estilo = Lector.leerString();
            
            pareja1 = new Parejas(estilo,parti1,parti2);
            
            parejas[dimL] = pareja1;
            dimL++;
        }
    }
    
    public Parejas obtenerParejaConMasDiferencia(){
        Parejas aux = null;
        int i;
        int maxDiferencia = -1;
        for(i = 0; i<= (dimL - 1); i++){
            if(parejas[i].obtenerDiferenciaEdad() > maxDiferencia){
                maxDiferencia = parejas[i].obtenerDiferenciaEdad();
                aux = parejas[i];
            }
        }
        return aux;
    }
    
}
