/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalserviciometero;

/**
 *
 * @author Usuario
 */
public class Estacion {
    private String nombre;
    private int latitud;
    private int longitud;

    public Estacion(String nombre, int latitud, int longitud) {
        this.nombre = nombre;
        this.latitud = latitud;
        this.longitud = longitud;
    }

    public String getNombre() {
        return nombre;
    }

    public int getLatitud() {
        return latitud;
    }

    public int getLongitud() {
        return longitud;
    }
    
    
}
