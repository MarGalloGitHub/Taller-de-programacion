/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalserviciometero;

/**
 *
 * @author Usuario
 */
public class SistemaAnual extends Sistema{

    public SistemaAnual(Estacion estacion1, int cantidadAños) {
        super(estacion1, cantidadAños);
    }
    
    @Override
    public String toString(){
        String aux = super.toString();
        double prom = 0;
        int i;
        int j;
        for(i=0 ; (i<= (this.getCantidadAños()-1)  ); i++){
            prom = 0;
            aux+= "Año: " + (i + 1 + 2024 - this.getCantidadAños()) + ":  ";
            for(j=0 ; j<= 11 ; j++){
                prom += this.getTemperaturas()[i][j];
            }
            aux+= (prom / 12.0) + "  C°";
        }
        return aux;
    }
    
}
