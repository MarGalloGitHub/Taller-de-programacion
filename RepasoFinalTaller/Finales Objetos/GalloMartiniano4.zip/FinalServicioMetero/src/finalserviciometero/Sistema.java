/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalserviciometero;

/**
 *
 * @author Usuario
 */
public abstract class Sistema {
    private Estacion estacion1;
    private int cantidadAños;
    private double[][] temperaturas;

    public Sistema(Estacion estacion1, int cantidadAños) {
        this.estacion1 = estacion1;
        this.cantidadAños = cantidadAños;
        temperaturas = new double[cantidadAños][12]; // inicializa java por mi todo en 0
    }
    
    public void registrarTemperatura(int año, int mes, double temp1){
        if((mes <= 12) && (año <= 2024) && (año >= (2024 - this.cantidadAños))){
            temperaturas[año - 2024 + (this.cantidadAños)][mes] = temp1;
         }
    }
    
    public double devolverTemperatura(int año, int mes){
        double aux = 0;
        if((mes <= 12) && (año <= 2024) && (año >= (2024 - this.cantidadAños))){
            aux = temperaturas[año - 2024 + (this.cantidadAños - 1)][mes - 1]; 
        }    
        return aux;
    }

    public Estacion getEstacion1() {
        return estacion1;
    }

    public int getCantidadAños() {
        return cantidadAños;
    }

    public double[][] getTemperaturas() {
        return temperaturas;
    }
    
    
    
    public String temperaturaMax(){
        int i;
        int j;
        int mesMax = 0;
        int añoMax = 0;
        double maxTemperatura = -1;
        String aux = "La temperatura mas alta registra es de la siguiente fecha: " + "\n";
        for(i=0 ; i<= (cantidadAños - 1) ; i++){
            for(j=0 ; j<= 11 ; j++){
                if(temperaturas[i][j] > maxTemperatura){
                    maxTemperatura = temperaturas[i][j];
                    añoMax = i;
                    mesMax = j;
                }
            }
        }
        aux += "Año: " + (añoMax + (2024 - cantidadAños) + 1 ) + "  y mes:  " + mesMax;
        return aux;
    }
    
    @Override
    public String toString(){
        String aux = "Informacion:  " + this.estacion1.getNombre() + "-- (" + this.estacion1.getLongitud() + "  S - " + this.estacion1.getLatitud() + "  O): ";
        return aux;
    }
    
}
