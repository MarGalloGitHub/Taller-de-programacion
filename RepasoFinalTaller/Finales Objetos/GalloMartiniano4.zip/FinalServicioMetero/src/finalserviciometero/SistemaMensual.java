/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalserviciometero;

/**
 *
 * @author Usuario
 */
public class SistemaMensual extends Sistema {

    public SistemaMensual(Estacion estacion1, int cantidadAños) {
        super(estacion1, cantidadAños);
    }
    
    @Override
    public String toString(){
        String aux = super.toString();
        int i;
        int j;
        double prom = 0;
        for(j=0 ; j<= 11 ; j++){
            aux+= "Mes: " + (j + 1) + ":  ";
            prom = 0;
            for(i=0 ; i<= (this.getCantidadAños() - 1) ; i++){
                prom+= this.getTemperaturas()[i][j];
            }
        }
        prom = (prom / this.getCantidadAños());
        aux += prom +  "  C°";
        return aux;
    }
    
}
