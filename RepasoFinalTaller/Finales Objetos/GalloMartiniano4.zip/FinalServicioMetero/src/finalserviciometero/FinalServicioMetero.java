/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalserviciometero;

/**
 *
 * @author Usuario
 */
import PaqueteLectura.Lector;
import PaqueteLectura.GeneradorAleatorio;
public class FinalServicioMetero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PaqueteLectura.GeneradorAleatorio.iniciar();
        
        Estacion estacion1 = new Estacion("Mi casa",365,471);
        
        
        SistemaMensual mensual = new SistemaMensual(estacion1,3);
        
        int i;
        int j;
        for(i=0 ; i<= 2 ; i++){
            for(j= 0 ; j<= 11 ; j++){
                mensual.registrarTemperatura(((2024 - 3) + i), j, GeneradorAleatorio.generarDouble(25));
            }
        }
        
        System.out.println(mensual.temperaturaMax());
        System.out.println(mensual.toString());
        
        
        SistemaAnual anual = new SistemaAnual(estacion1,4);
        
        for(i=0 ; i<= 3 ; i++){
            for(j=0 ; j<= 11 ; j++){
                anual.registrarTemperatura(((2024 - 4) + i), j, GeneradorAleatorio.generarDouble(25));
            }
        }
        
        System.out.println(anual.temperaturaMax());
        System.out.println(anual.toString());
    }   
    
}
